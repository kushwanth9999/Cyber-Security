# Tools Used for Phishing Analysis

- **MXToolbox Email Header Analyzer**  
  https://mxtoolbox.com/EmailHeaders.aspx

- **VirusTotal Link Scanner**  
  https://www.virustotal.com

- **Whois Domain Lookup**  
  https://who.is/

- **Phishing Sample Sources**  
  https://www.phishing.org/phishing-examples  
  https://haveibeenpwned.com/
