# Cyber Security Internship - Task 2: Phishing Email Analysis

## 🧠 Objective
Analyze a suspicious email to identify phishing characteristics and improve awareness of email-based threats.

## 📄 Task Summary
- Reviewed a fake PayPal phishing email.
- Identified common phishing indicators.
- Used online tools to validate email authenticity.
- Prepared a structured report with findings.

## 🛠 Tools Used
- [MXToolbox Email Header Analyzer](https://mxtoolbox.com/EmailHeaders.aspx)
- Whois Lookup
- Hover-over link inspection
- VirusTotal

## 📂 Contents
- `phishing_report.md`: Detailed analysis of the phishing email.
- `email_sample.png`: Screenshot of the phishing email.
- `tools_used.md`: Links to tools and brief usage notes.

## 🔗 Submission Info
Submitted as part of the Cyber Security Internship - Task 2.
